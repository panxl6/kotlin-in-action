package ch07.RangePriority

fun main(args: Array<String>) {
    val n = 9
    println(0..(n + 1))
    (0..n).forEach { print(it) }
}
