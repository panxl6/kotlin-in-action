package ch03.MakingFunctionsEasierToCall

fun main(args: Array<String>) {
    val list = listOf(1, 2, 3)
    println(list)
}
