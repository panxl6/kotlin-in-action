package ch03.SplittingStrings1

fun main(args: Array<String>) {
    println("12.345-6.A".split(".", "-"))
}
