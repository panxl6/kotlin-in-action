package ch02.EasierStringFormattingStringTemplates1

fun main(args: Array<String>) {
    if (args.size > 0) {
        println("Hello, ${args[0]}!")
    }
}
