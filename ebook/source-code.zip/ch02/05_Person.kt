package ch02.Person

class Person(
        val name: String,
        var isMarried: Boolean
)
