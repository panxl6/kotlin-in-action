package ch02.HelloWorld

fun main(args: Array<String>) {
    println("Hello, world!")
}
