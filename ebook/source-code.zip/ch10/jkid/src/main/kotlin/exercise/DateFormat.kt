package ru.yole.jkid

@Target(AnnotationTarget.PROPERTY)
annotation class DateFormat(val format: String)
