package ch05.TheSyntaxForLambdaExpressions2

fun main(args: Array<String>) {
    run { println(42) }
}
