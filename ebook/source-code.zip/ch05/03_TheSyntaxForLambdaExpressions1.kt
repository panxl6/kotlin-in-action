package ch05.TheSyntaxForLambdaExpressions1

fun main(args: Array<String>) {
    { println(42) }()
}
