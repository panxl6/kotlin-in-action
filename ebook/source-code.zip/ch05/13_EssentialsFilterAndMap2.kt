package ch05.EssentialsFilterAndMap2

fun main(args: Array<String>) {
    val list = listOf(1, 2, 3, 4)
    list.map { it * it }
}
