package ch04.Client

class Client(val name: String, val postalCode: Int)
