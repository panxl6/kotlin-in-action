package ch04.InitializingClassesPrimaryConstructorAndInitializerBlocks3

class User(val nickname: String)
