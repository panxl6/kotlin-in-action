package ch04.KotlinDataClass

data class Client(val name: String, val postalCode: Int)
