package ch04.InitializingClassesPrimaryConstructorAndInitializerBlocks2

class User(_nickname: String) {
    val nickname = _nickname
}
