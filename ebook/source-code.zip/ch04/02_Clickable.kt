package ch04.Clickable

interface Clickable {
    fun click()
    fun showOff() = println("I'm clickable!")
}
