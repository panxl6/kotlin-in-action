package ch04.InitializingClassesPrimaryConstructorAndInitializerBlocks

class User(val nickname: String)
